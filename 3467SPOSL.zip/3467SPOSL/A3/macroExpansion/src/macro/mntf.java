package macro;

class mntf{
	String macro_name;
	int pp;
	int kp;
	int kpdtp;
	int mdtp;
	
	public mntf(){
		macro_name=new String();
		pp=kp=mdtp=kpdtp=0;
	}
}